# 40-task figure/table data package

This package regenerates paper figures/tables for the sensitivity set that removes
`segments_intersect`, `knap`, `gcp`, and `spp` from the current 44-task route-analysis set.

Use these files for figure generation:

- `main_route_summary_40_tasks.csv`: Fig. 3 aggregate bars and headline route differences.
- `fig3_bootstrap_deltas_cluster_40_tasks.csv`: preferred paired-delta bootstrap distributions for Fig. 3.
- `fig3_bootstrap_deltas_row_40_tasks.csv`: row bootstrap distribution matching simpler row-level sensitivity checks.
- `route_accuracy_by_task_40_tasks.csv`: task-level route accuracies for Fig. 4.
- `route_accuracy_by_task_digit_40_tasks.csv`: task/difficulty route accuracies for Fig. 4 hardness panels.
- `fig6_recovery_by_digit_40_tasks.csv`: recovery and execution-win mass by difficulty for Fig. 6.
- `fig6_recovery_by_task_40_tasks.csv`: task-level recovery diagnostics for Fig. 6 or appendix.

Use these files for appendix/table updates:

- `route_accuracy_by_complexity_40_tasks.csv`
- `route_accuracy_by_model_40_tasks.csv`
- `code_failure_distribution_40_tasks.csv`
- `summary_for_paper.md`

`raw_filtered_outcomes_minimal_40_tasks.csv` is included so the figures can be
recomputed from row-level outcomes without reopening the full JSONL artifacts.
