# 40-task subset summary

Dropped from the current 44-task main set: `segments_intersect`, `knap`, `gcp`, `spp`.

Rows: 20034; unique problem instances: 1113; tasks: 40; models: 6; seeds: 3.
Route 1 / NL accuracy: 17.2107%
Route 2 / Sim accuracy: 17.3655%
Route 3 / Code Exec accuracy: 48.8370%
Sim - NL: 0.1547 pp
Code Exec - Sim: 31.4715 pp
Code Exec - NL: 31.6262 pp
Row bootstrap CI Sim-NL: [-0.1897, 0.4992] pp
Cluster bootstrap CI Sim-NL: [-0.2995, 0.6140] pp

## Appendix complexity table rows
O(1) & 3 & 180 & 46.2 & 47.3 & 86.2 & 1.0 & 0.0206 & 39.0 \
O(log n) & 1 & 35 & 22.4 & 28.6 & 32.9 & 6.2 & 2.7e-04 & 4.3 \
O(n) & 4 & 135 & 4.8 & 5.0 & 7.5 & 0.2 & 0.635 & 2.5 \
O(n log n) & 5 & 68 & 0.0 & 0.0 & 0.0 & 0.0 & 1 & 0.0 \
O(n^2) & 16 & 297 & 10.3 & 10.5 & 38.9 & 0.1 & 0.644 & 28.5 \
O(n^2 log n) & 1 & 1 & 0.0 & 0.0 & 0.0 & 0.0 & 1 & 0.0 \
O(n^3) & 4 & 37 & 0.0 & 0.0 & 0.0 & 0.0 & 1 & 0.0 \
NP-hard & 6 & 360 & 17.6 & 16.8 & 69.7 & -0.8 & 0.0278 & 53.0 \

## Appendix model table rows
\path{anthropic/claude-haiku-4.5} & closed & 1113 & 23.3 & 23.6 & 47.1 & 0.3 & 0.612 & 23.5 & 2.4e-148 \
\path{google/gemini-2.0-flash-001} & closed & 1113 & 17.5 & 18.1 & 51.8 & 0.7 & 0.137 & 33.7 & 8.5e-298 \
\path{google/gemini-2.5-flash} & closed & 1113 & 20.7 & 20.5 & 50.2 & -0.1 & 0.823 & 29.7 & 3.1e-238 \
\path{openai/gpt-4o-mini} & closed & 1113 & 14.1 & 12.9 & 49.1 & -1.2 & 0.00663 & 36.1 & <1e-300 \
\path{mistralai/codestral-2508} & open & 1113 & 15.0 & 15.8 & 52.7 & 0.8 & 0.0279 & 36.9 & <1e-300 \
\path{mistralai/mixtral-8x22b-instruct} & open & 1113 & 12.7 & 13.2 & 42.1 & 0.5 & 0.127 & 28.9 & 7.2e-253 \
